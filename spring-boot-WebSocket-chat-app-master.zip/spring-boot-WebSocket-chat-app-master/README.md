# spring-boot-WebSocket-chat-app
# This app is live at https://spring-boot-chat-application.herokuapp.com/

# I have created the video as well as article which help you to understand how this app has been build.
Article: https://www.pixeltrice.com/build-spring-boot-chat-application-from-scratch/
Video: https://www.youtube.com/watch?v=IwYmskBswPg
